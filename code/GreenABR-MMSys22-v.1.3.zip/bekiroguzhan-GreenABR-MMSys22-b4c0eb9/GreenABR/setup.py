import os 


os.system("pip install keras==2.3.1")
os.system("pip install numpy==1.16.4")
os.system("pip install matplotlib==3.1.0")
os.system("pip install pandas==0.24.2")
os.system("pip install joblib==1.0.1")
os.system("pip install tensorflow==1.14.0")
os.system("pip install scikit-learn==0.21.2")